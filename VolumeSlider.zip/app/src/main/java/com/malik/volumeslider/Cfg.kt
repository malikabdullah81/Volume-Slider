package com.malik.volumeslider

import android.content.Context

class Setting(
    val key: String,
    val label: String,
    val def: Float,
    val min: Float = 0f,
    val max: Float = 1f,
    val unit: String = "",
    val kind: Int = SLIDER,
    val options: List<String> = emptyList()
) {
    companion object {
        const val SLIDER = 0
        const val TOGGLE = 1
        const val CHOICE = 2
    }
}

object Cfg {
    val sections: List<Pair<String, List<Setting>>> = listOf(
        "General" to listOf(
            Setting("enabled", "Replace system volume panel", 1f, kind = Setting.TOGGLE),
            Setting("side", "Panel side", 0f, kind = Setting.CHOICE, options = listOf("Right", "Left")),
            Setting("haptics", "Haptic ticks", 1f, kind = Setting.TOGGLE),
            Setting("hideMs", "Hide delay", 2200f, 800f, 6000f, " ms"),
            Setting("percent", "Show percentage", 0f, kind = Setting.TOGGLE),
        ),
        "Layout" to listOf(
            Setting("width", "Width", 72f, 44f, 140f, " dp"),
            Setting("height", "Height", 250f, 140f, 420f, " dp"),
            Setting("margin", "Distance from screen edge", 12f, 0f, 60f, " dp"),
            Setting("yoff", "Vertical offset", 0f, -300f, 300f, " dp"),
            Setting("round", "Corner roundness", 100f, 20f, 100f, " %")
        ),
        "Physics" to listOf(
            Setting("kFill", "Fill spring stiffness", 380f, 80f, 1400f),
            Setting("zFill", "Fill damping (low = bouncier)", 52f, 15f, 100f, " %"),
            Setting("kDrag", "Finger follow stiffness", 1100f, 300f, 3000f),
            Setting("squash", "Jelly squash and stretch", 60f, 0f, 150f, " %"),
            Setting("wave", "Liquid surface wave", 60f, 0f, 150f, " %"),
            Setting("rubber", "Rubber band at the ends", 60f, 0f, 150f, " %"),
            Setting("kPop", "Entrance stiffness", 320f, 80f, 1200f),
            Setting("zPop", "Entrance damping (low = bouncier)", 45f, 15f, 100f, " %"),
            Setting("popDist", "Entrance slide distance", 70f, 0f, 200f, " dp")
        ),
        "Look" to listOf(
            Setting("glass", "Glass style", 1f, kind = Setting.TOGGLE),
            Setting("track", "Track opacity", 30f, 5f, 90f, " %"),
            Setting("fillA", "Fill opacity", 92f, 20f, 100f, " %"),
            Setting("hue", "Fill hue", 210f, 0f, 360f, " deg"),
            Setting("sat", "Fill colour strength (0 = white)", 0f, 0f, 100f, " %"),
            Setting("glow", "Edge glow (0 = no edge line)", 70f, 0f, 100f, " %"),
            Setting("spec", "Glass highlight", 60f, 0f, 100f, " %"),
            Setting("shadow", "Shadow", 35f, 0f, 100f, " %"),
            Setting("blur", "Real backdrop blur (experimental)", 0f, 0f, 60f, " px"),
            Setting("glassTint", "Frosted tint strength", 42f, 0f, 100f, " %"),
            Setting("frost", "Frosted glass density", 58f, 0f, 100f, " %"),
            Setting("refract", "Refractive edge depth", 55f, 0f, 100f, " %"),
            Setting("shinePos", "Reflection position", 35f, 0f, 100f, " %"),
            Setting("shineWidth", "Reflection width", 38f, 10f, 90f, " %"),
            Setting("glassHue", "Glass tint hue", 225f, 0f, 360f, " deg"),
            Setting("glassSat", "Glass tint saturation", 28f, 0f, 100f, " %")
        )
    )

    private val all: Map<String, Setting> = sections.flatMap { it.second }.associateBy { it.key }
    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun f(c: Context, key: String): Float = prefs(c).getFloat(key, all.getValue(key).def)
    fun set(c: Context, key: String, v: Float) { prefs(c).edit().putFloat(key, v).apply() }
    fun reset(c: Context) { prefs(c).edit().clear().apply() }
}
