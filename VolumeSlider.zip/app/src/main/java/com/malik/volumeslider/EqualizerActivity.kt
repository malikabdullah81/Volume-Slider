package com.malik.volumeslider

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class EqualizerActivity : Activity() {
    private var eq: Equalizer? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 15f) = TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xE8B8C9E8.toInt(), 0xE82D5B9B.toInt(), 0xE84C477E.toInt())).apply { cornerRadius=dp(28).toFloat() }
        }
        root.addView(label("Equalizer", 25f))
        root.addView(label("System output effect · availability depends on device", 12f))
        try { eq = Equalizer(0, 0).apply { enabled = true } }
        catch (_: Exception) { Toast.makeText(this, "Global equalizer is not available on this device", Toast.LENGTH_LONG).show() }
        val effect = eq
        fun bandFor(freq: Int): Short? {
            if (effect == null) return null
            for (i in 0 until effect.numberOfBands) {
                val range = effect.getBandFreqRange(i.toShort())
                if (freq * 1000 in range[0]..range[1]) return i.toShort()
            }
            return null
        }
        fun addControl(name: String, freq: Int, curve: Float = 1f) {
            root.addView(label(name).apply { setPadding(0, dp(14), 0, dp(2)) })
            val bar = SeekBar(this)
            bar.max = 100
            bar.progress = 50
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser || effect == null) return
                    val band = bandFor(freq) ?: return
                    val range = effect.bandLevelRange
                    val level = (range[0] + (range[1] - range[0]) * p / 100f * curve).toInt()
                        .coerceIn(range[0].toInt(), range[1].toInt()).toShort()
                    try { effect.setBandLevel(band, level) } catch (_: Exception) { }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            root.addView(bar)
        }
        addControl("Bass", 100)
        addControl("Treble", 10000)
        addControl("Instrument presence", 1200)
        addControl("Vocal clarity", 3000)
        root.addView(label("Presets", 17f).apply { setPadding(0, dp(16), 0, dp(4)) })
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (name in listOf("Flat", "Bass", "Vocal", "Bright")) {
            presets.addView(Button(this).apply { text=name; isAllCaps=false; setOnClickListener {
                val e = eq
                if (e != null) try {
                    val preset = when(name) { "Bass" -> 1; "Vocal" -> 2; "Bright" -> 3; else -> 0 }
                    if (e.numberOfPresets > preset) e.usePreset(preset.toShort())
                } catch (_: Exception) { }
            } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(presets)
        root.addView(label("UHQ upscaler, Concert Hall and Dolby Atmos are Samsung/device-specific effects. Use phone Sound settings when supported.", 12f).apply { setPadding(0, dp(14), 0, dp(8)) })
        root.addView(Button(this).apply { text="Open device sound settings"; setOnClickListener {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)) } catch (_: Exception) { }
        } })
        root.addView(Button(this).apply { text="Close"; setOnClickListener { finish() } })
        setContentView(root)
    }
    override fun onDestroy() { try { eq?.release() } catch (_: Exception) {}; eq=null; super.onDestroy() }
}
