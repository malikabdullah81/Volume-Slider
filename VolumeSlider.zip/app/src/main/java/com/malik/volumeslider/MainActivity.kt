package com.malik.volumeslider

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var preview: PanelView
    private lateinit var status: TextView
    private var level = 0.6f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(label: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = label
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        col.addView(tv("Volume Slider", 26f, bold = true))
        status = tv("", 14f, 0xFFB8B8C0.toInt())
        status.setPadding(0, dp(6), 0, dp(6))
        col.addView(status)

        col.addView(btn("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("App info (Allow restricted settings)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        // live preview on a colourful backdrop so the glass is visible
        val holder = FrameLayout(this)
        holder.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF6A3DE8.toInt(), 0xFF1FB6C8.toInt(), 0xFFF0A04B.toInt())
        ).apply { cornerRadius = dp(24).toFloat() }
        col.addView(holder, LinearLayout.LayoutParams(-1, dp(360)).apply { topMargin = dp(12) })

        preview = PanelView(this)
        preview.steps = 15
        preview.listener = object : PanelView.Listener {
            override fun onUserLevel(frac: Float) {
                level = frac
            }

            override fun onTouch(down: Boolean) {}
        }
        holder.addView(preview, FrameLayout.LayoutParams(-2, -2))
        preview.snapLevel(level)
        refreshPreview()
        preview.popIn()

        val row = LinearLayout(this)
        fun add(b: Button) = row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        add(btn("Vol -") { bump(-1) })
        add(btn("Vol +") { bump(1) })
        add(btn("Replay") { replay() })
        add(btn("Reset") {
            Cfg.reset(this)
            recreate()
        })
        col.addView(row)

        for ((title, list) in Cfg.sections) {
            col.addView(tv(title, 18f, 0xFF9CC4FF.toInt(), true).apply { setPadding(0, dp(22), 0, dp(4)) })
            for (s in list) col.addView(settingView(s))
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF101014.toInt())
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        status.text = if (on) "Service is ON. The volume keys now show this panel."
        else "Service is OFF. Turn it on in Accessibility > Installed apps > Volume Slider."
    }

    private fun refreshPreview() {
        preview.applyConfig()
        val lp = preview.layoutParams as FrameLayout.LayoutParams
        lp.gravity = (if (preview.right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        val m = maxOf(0f, preview.marginPx - preview.pad).toInt()
        lp.leftMargin = if (preview.right) 0 else m
        lp.rightMargin = if (preview.right) m else 0
        preview.layoutParams = lp
    }

    private fun bump(dir: Int) {
        val n = (level * 15f).roundToInt() + dir
        if (n < 0 || n > 15) {
            preview.nudge(dir)
            return
        }
        level = n / 15f
        preview.setLevel(level)
    }

    private fun replay() {
        preview.popOut()
        preview.postDelayed({ preview.popIn() }, 550)
    }

    private fun settingView(s: Setting): View {
        val v = Cfg.f(this, s.key)
        return when (s.kind) {
            Setting.TOGGLE -> Switch(this).apply {
                text = s.label
                setTextColor(Color.WHITE)
                isChecked = v > 0.5f
                setPadding(0, dp(8), 0, dp(8))
                setOnCheckedChangeListener { _, on ->
                    Cfg.set(this@MainActivity, s.key, if (on) 1f else 0f)
                    refreshPreview()
                }
            }
            Setting.CHOICE -> Button(this).apply {
                isAllCaps = false
                fun upd() {
                    text = s.label + ": " + s.options[Cfg.f(this@MainActivity, s.key).toInt()]
                }
                upd()
                setOnClickListener {
                    val n = (Cfg.f(this@MainActivity, s.key).toInt() + 1) % s.options.size
                    Cfg.set(this@MainActivity, s.key, n.toFloat())
                    upd()
                    refreshPreview()
                }
            }
            else -> LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(6), 0, dp(6))
                val label = tv("", 14f)
                fun fmt(x: Float) = s.label + ": " + x.roundToInt() + s.unit
                label.text = fmt(v)
                val bar = SeekBar(this@MainActivity)
                bar.max = 1000
                bar.progress = (((v - s.min) / (s.max - s.min)) * 1000f).toInt()
                bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val x = s.min + (s.max - s.min) * p / 1000f
                        Cfg.set(this@MainActivity, s.key, x)
                        label.text = fmt(x)
                        refreshPreview()
                    }

                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
                addView(label)
                addView(bar)
            }
        }
    }
}
