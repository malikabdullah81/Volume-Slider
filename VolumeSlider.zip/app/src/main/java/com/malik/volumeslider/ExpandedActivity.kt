package com.malik.volumeslider

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** One UI-inspired expanded stream mixer. Stream availability/behavior remains device dependent. */
class ExpandedActivity : Activity() {
    private val streams = listOf(
        "Alarm" to AudioManager.STREAM_ALARM,
        "Ringtone" to AudioManager.STREAM_RING,
        "Media" to AudioManager.STREAM_MUSIC,
        "Voice" to AudioManager.STREAM_VOICE_CALL,
        "Notifications" to AudioManager.STREAM_NOTIFICATION
    )
    private lateinit var audio: AudioManager
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xE8B8C9E8.toInt(), 0xE82D5B9B.toInt(), 0xE84C477E.toInt())).apply { cornerRadius = dp(30).toFloat() }
        }
        root.addView(text("Volume controls", 24f, Color.BLACK).apply { typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        root.addView(text("Adjust each audio stream", 13f, 0xFF30364B.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(14)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 5f }
        for ((label, stream) in streams) {
            val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), 0, dp(3), 0) }
            val maxVolume = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
            val current = audio.getStreamVolume(stream)
            column.addView(text("$current", 12f, Color.WHITE).apply { gravity = Gravity.CENTER })
            val seek = SeekBar(this).apply {
                setMax(maxVolume)
                progress = current.coerceIn(0, maxVolume)
                rotation = -90f
                progressTintList = android.content.res.ColorStateList.valueOf(0xFF52E8BE.toInt())
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(b: SeekBar?, value: Int, fromUser: Boolean) {
                        if (fromUser) { audio.setStreamVolume(stream, value, 0); (column.getChildAt(0) as TextView).text = value.toString() }
                    }
                    override fun onStartTrackingTouch(b: SeekBar?) {}
                    override fun onStopTrackingTouch(b: SeekBar?) {}
                })
            }
            column.addView(seek, LinearLayout.LayoutParams(dp(150), dp(42)).apply { topMargin = dp(62); bottomMargin = dp(62) })
            column.addView(text(label, 11f, Color.BLACK).apply { gravity = Gravity.CENTER })
            row.addView(column, LinearLayout.LayoutParams(0, dp(260), 1f))
        }
        root.addView(row)
        val divider = android.view.View(this).apply { setBackgroundColor(0x99FFFFFF.toInt()) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) })
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 4f }
        fun shortcut(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; isAllCaps = false; textSize = 11f; setOnClickListener { action() } }
            shortcuts.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        shortcut("Bluetooth") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        shortcut("Mute") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0) }
        shortcut("Sound") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
        shortcut("Equalizer") { startActivity(Intent(this, EqualizerActivity::class.java)) }
        root.addView(shortcuts)
        root.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } })
        setContentView(root)
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = 0xFF10152B.toInt()
    }
}
