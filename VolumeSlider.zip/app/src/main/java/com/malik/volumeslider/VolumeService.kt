package com.malik.volumeslider

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

/**
 * Catches the hardware volume keys, changes the volume itself (no system panel),
 * and shows the animated PanelView in an accessibility overlay window.
 */
class VolumeService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private val vib by lazy { (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator }
    private var panel: PanelView? = null
    private var attached = false
    private var stream = AudioManager.STREAM_MUSIC
    private var lastIdx = -1
    private val handler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { panel?.popOut() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (Cfg.f(this, "enabled") < 0.5f) return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            step(if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER)
        }
        return true
    }

    private fun pickStream(): Int = when (audio.mode) {
        AudioManager.MODE_IN_CALL, AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        AudioManager.MODE_RINGTONE -> AudioManager.STREAM_RING
        else -> AudioManager.STREAM_MUSIC
    }

    private fun step(dir: Int) {
        stream = pickStream()
        val max = audio.getStreamMaxVolume(stream)
        val before = audio.getStreamVolume(stream)
        try {
            audio.adjustStreamVolume(stream, dir, 0)
        } catch (e: Exception) {
        }
        val after = audio.getStreamVolume(stream)

        val p = ensurePanel()
        p.steps = max
        if (!attached) p.snapLevel(before.toFloat() / max)
        show(p)
        p.setLevel(after.toFloat() / max)
        if (after != before) {
            lastIdx = after
            tick()
        } else {
            p.nudge(if (dir == AudioManager.ADJUST_RAISE) 1 else -1)
        }
        scheduleHide()
    }

    private fun tick() {
        if (Cfg.f(this, "haptics") > 0.5f) {
            vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        }
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, Cfg.f(this, "hideMs").toLong())
    }

    private fun ensurePanel(): PanelView {
        panel?.let { return it }
        val p = PanelView(this)
        p.listener = object : PanelView.Listener {
            override fun onUserLevel(frac: Float) {
                val max = audio.getStreamMaxVolume(stream)
                val idx = (frac * max).roundToInt()
                try {
                    audio.setStreamVolume(stream, idx, 0)
                } catch (e: Exception) {
                }
                if (idx != lastIdx) {
                    lastIdx = idx
                    tick()
                }
            }

            override fun onTouch(down: Boolean) {
                if (down) handler.removeCallbacks(hideRun) else scheduleHide()
            }
        }
        p.onHidden = {
            if (attached && p.isHidden()) {
                try {
                    wm.removeView(p)
                } catch (e: Exception) {
                }
                attached = false
            }
        }
        panel = p
        return p
    }

    private fun show(p: PanelView) {
        p.applyConfig()
        val flags = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or
            WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS
        val lp = WLP(p.wantedW(), p.wantedH(), WLP.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        lp.gravity = (if (p.onRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        lp.x = (p.marginPx - p.pad).toInt()
        lp.y = p.yOffPx.toInt()
        lp.layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        if (p.blurPx > 0f && wm.isCrossWindowBlurEnabled) {
            lp.flags = lp.flags or WLP.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = p.blurPx.toInt()
        }
        if (attached) wm.updateViewLayout(p, lp) else {
            wm.addView(p, lp)
            attached = true
        }
        p.popIn()
    }

    private fun detach() {
        handler.removeCallbacks(hideRun)
        val p = panel
        if (attached && p != null) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
        attached = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        detach()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        detach()
        super.onDestroy()
    }
}
