package com.malik.volumeslider

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Damped spring (mass 1). x chases target; v is velocity. Sub-stepped so it stays stable. */
class Spring {
    var x = 0f
    var v = 0f
    var target = 0f

    fun step(dt: Float, k: Float, zeta: Float) {
        val c = 2f * zeta * sqrt(k)
        var left = dt
        while (left > 0f) {
            val h = min(left, 1f / 240f)
            v += (k * (target - x) - c * v) * h
            x += v * h
            left -= h
        }
    }

    fun settled(eps: Float = 0.0015f) = abs(x - target) < eps && abs(v) < eps * 8f

    fun snap(t: Float) {
        x = t
        target = t
        v = 0f
    }
}

/** The vertical glass volume pill. Used both in the overlay window and in the settings preview. */
class PanelView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onUserLevel(frac: Float)
        fun onTouch(down: Boolean)
        fun onExpand() {}
    }

    var listener: Listener? = null
    var onHidden: (() -> Unit)? = null
    var steps = 15

    var onRight = true
        private set
    var marginPx = 0f
        private set
    var yOffPx = 0f
        private set
    var blurPx = 0f
        private set
    var pad = 0f
        private set

    private val d = ctx.resources.displayMetrics.density

    // physics state
    private val fill = Spring()
    private val squash = Spring()
    private val amp = Spring()
    private val rubber = Spring()
    private val pop = Spring()
    private var rubberDir = 1
    private var phase = 0f
    private var lastNs = 0L
    private var dragging = false
    private var menuPressed = false
    private var touchMoved = false
    private var downX = 0f
    private var downY = 0f
    private var hiddenSent = false

    // config (filled by applyConfig)
    private var pw = 72f * d
    private var ph = 250f * d
    private var radiusFrac = 1f
    private var kFill = 380f
    private var zFill = 0.52f
    private var kDrag = 1100f
    private var squashAmt = 0.6f
    private var waveAmt = 0.6f
    private var rubberAmt = 0.6f
    private var kPop = 320f
    private var zPop = 0.45f
    private var popDist = 70f * d
    private var glass = true
    private var trackA = 0.3f
    private var fillA = 0.92f
    private var hue = 210f
    private var sat = 0f
    private var glow = 0.7f
    private var spec = 0.6f
    private var shadowA = 0.35f
    private var showPct = false
    private var glassTint = 0.42f
    private var frost = 0.58f
    private var refract = 0.55f
    private var shinePos = 0.35f
    private var shineWidth = 0.38f
    private var glassHue = 225f
    private var glassSat = 0.28f

    // reusable drawing objects
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sh = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val rect2 = RectF()
    private val hl = RectF()
    private val arcRect = RectF()
    private val clip = Path()
    private val path = Path()
    private val topPath = Path()
    private val spk = Path().apply {
        moveTo(3f, 9.5f); lineTo(7f, 9.5f); lineTo(12.5f, 4.5f)
        lineTo(12.5f, 19.5f); lineTo(7f, 14.5f); lineTo(3f, 14.5f); close()
    }

    init {
        contentDescription = "Volume slider. Tap the three-dot menu at the top to expand volume controls; drag the slider to change volume."
        isClickable = true
        pop.snap(0f)
        applyConfig()
    }

    fun applyConfig() {
        val c = context
        fun g(k: String) = Cfg.f(c, k)
        pw = g("width") * d
        ph = g("height") * d
        radiusFrac = g("round") / 100f
        onRight = g("side") < 0.5f
        marginPx = g("margin") * d
        yOffPx = g("yoff") * d
        blurPx = g("blur")
        pad = if (blurPx > 0f) 0f else 32f * d
        kFill = g("kFill")
        zFill = g("zFill") / 100f
        kDrag = g("kDrag")
        squashAmt = g("squash") / 100f
        waveAmt = g("wave") / 100f
        rubberAmt = g("rubber") / 100f
        kPop = g("kPop")
        zPop = g("zPop") / 100f
        popDist = g("popDist") * d
        glass = g("glass") > 0.5f
        trackA = g("track") / 100f
        fillA = g("fillA") / 100f
        hue = g("hue")
        sat = g("sat") / 100f
        glow = g("glow") / 100f
        spec = g("spec") / 100f
        shadowA = g("shadow") / 100f
        showPct = g("percent") > 0.5f
        glassTint = g("glassTint") / 100f
        frost = g("frost") / 100f
        refract = g("refract") / 100f
        shinePos = g("shinePos") / 100f
        shineWidth = g("shineWidth") / 100f
        glassHue = g("glassHue")
        glassSat = g("glassSat") / 100f
        requestLayout()
        invalidate()
    }

    fun wantedW() = (pw + 2f * pad).toInt()
    fun wantedH() = (ph + 2f * pad).toInt()

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(wantedW(), wantedH())
    }

    // ---- control from outside ----
    fun snapLevel(f: Float) {
        fill.snap(f.coerceIn(0f, 1f))
        invalidate()
    }

    fun setLevel(f: Float) {
        if (!dragging) fill.target = f.coerceIn(0f, 1f)
        invalidate()
    }

    /** Kick when the volume is already at its limit: the panel jiggles instead of staying dead. */
    fun nudge(dir: Int) {
        fill.v += dir * (1.2f + 1.5f * squashAmt)
        invalidate()
    }

    fun popIn() {
        pop.target = 1f
        hiddenSent = false
        invalidate()
    }

    fun popOut() {
        pop.target = 0f
        invalidate()
    }

    fun isHidden() = pop.target == 0f && pop.settled()

    // ---- touch ----
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (pop.x < 0.5f || e.x < pad || e.x > pad + pw || e.y < pad || e.y > pad + ph) return false
                downX = e.x
                downY = e.y
                touchMoved = false
                // The three-dot menu occupies the top-center cap of the pill.
                // It is a dedicated hit target; touching/dragging the fill never expands.
                val menuX = pad + pw / 2f
                val menuY = pad + 22f * d
                menuPressed = abs(e.x - menuX) <= 24f * d && abs(e.y - menuY) <= 22f * d
                dragging = !menuPressed
                parent?.requestDisallowInterceptTouchEvent(true)
                listener?.onTouch(true)
                if (dragging) drag(e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 8f*d || abs(e.y - downY) > 8f*d) touchMoved = true
                if (dragging && touchMoved) drag(e.y)
                if (menuPressed && touchMoved) menuPressed = false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (menuPressed) {
                    val shouldExpand = e.actionMasked == MotionEvent.ACTION_UP && !touchMoved
                    menuPressed = false
                    if (shouldExpand) listener?.onExpand()
                    listener?.onTouch(false)
                } else if (dragging) {
                    dragging = false
                    rubber.target = 0f
                    fill.target = (fill.target * steps).roundToInt() / steps.toFloat()
                    listener?.onUserLevel(fill.target)
                    listener?.onTouch(false)
                } else {
                    // A menu tap cancelled by a finger move still ends the touch session.
                    listener?.onTouch(false)
                }
                invalidate()
            }
        }
        return true
    }

    private fun drag(y: Float) {
        val raw = 1f - (y - pad) / ph
        val over = if (raw > 1f) raw - 1f else if (raw < 0f) -raw else 0f
        if (over > 0f) rubberDir = if (raw > 1f) 1 else -1
        rubber.target = ((1f - exp(-over * 3f)) * 0.10f * rubberAmt).coerceAtMost(0.12f)
        fill.target = raw.coerceIn(0f, 1f)
        listener?.onUserLevel(fill.target)
        invalidate()
    }

    // ---- drawing ----
    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 1f / 60f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 1f / 30f)
        lastNs = now

        fill.step(dt, if (dragging) kDrag else kFill, if (dragging) 0.9f else zFill)
        squash.target = (fill.v * 0.12f * squashAmt).coerceIn(-0.1f, 0.1f)
        squash.step(dt, 520f, 0.42f)
        amp.target = min(abs(fill.v) * 0.8f, 1f) * waveAmt
        amp.step(dt, 220f, 0.35f)
        rubber.step(dt, 420f, if (dragging) 0.9f else 0.35f)
        pop.step(dt, kPop, if (pop.target == 0f) 0.9f else zPop)
        phase += dt * 9f

        val a = pop.x.coerceIn(0f, 1f)
        if (a > 0.003f) drawPanel(c, a)

        if (pop.target == 0f && pop.settled() && !hiddenSent) {
            hiddenSent = true
            post { onHidden?.invoke() }
        }
        val busy = dragging || !fill.settled() || !squash.settled() || !amp.settled(0.004f) ||
            !rubber.settled() || !pop.settled()
        if (busy) postInvalidateOnAnimation() else lastNs = 0L
    }

    private fun withA(color: Int, f: Float) =
        Color.argb((Color.alpha(color) * f).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    private fun drawPanel(c: Canvas, a: Float) {
        val l = pad
        val t = pad
        val r = pad + pw
        val b = pad + ph
        val cx = (l + r) / 2f
        val sgn = if (onRight) 1f else -1f

        // jelly transform: squash/stretch + rubber band, pivoting on the edge being pulled
        val sy = 1f + squash.x + rubber.x
        val sx = 1f - squash.x * 0.5f
        val shift = rubberDir * (ph / 2f) * (rubber.x * 20f).coerceIn(0f, 1f)
        val ps = 0.86f + 0.14f * pop.x

        c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (a * 255f).toInt())
        c.translate((1f - pop.x) * popDist * sgn, 0f)
        c.scale(ps, ps, width / 2f, height / 2f)
        c.scale(sx, sy, width / 2f, height / 2f + shift)

        rect.set(l, t, r, b)
        val rad = radiusFrac * pw / 2f
        clip.reset()
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW)

        // soft shadow, only outside the pill so the glass stays clear
        if (shadowA > 0f && pad > 0f) {
            c.save()
            c.clipOutPath(clip)
            sh.color = Color.BLACK
            sh.setShadowLayer(16f * d, 0f, 5f * d, Color.argb((shadowA * 130f).toInt(), 0, 0, 0))
            c.drawRoundRect(rect, rad, rad, sh)
            c.restore()
        }

        c.save()
        c.clipPath(clip)

        // track
        p.shader = null
        if (glass) {
            p.color = Color.argb((trackA * 140f).toInt(), 10, 10, 16)
            c.drawRect(rect, p)
            val tint = Color.HSVToColor((glassTint * 150f).toInt(), floatArrayOf(glassHue, glassSat, 1f))
            p.shader = LinearGradient(l, t, r, b,
                Color.argb((glassTint * 125f).toInt(), Color.red(tint), Color.green(tint), Color.blue(tint)),
                Color.argb((glassTint * 65f).toInt(), Color.red(tint), Color.green(tint), Color.blue(tint)),
                Shader.TileMode.CLAMP)
            c.drawRect(rect, p)
            p.shader = null
            p.color = Color.argb((frost * 42f).toInt(), 255, 255, 255)
            c.drawRect(rect, p)
            p.shader = LinearGradient(
                0f, t, 0f, b,
                Color.argb((trackA * 230f).toInt(), 255, 255, 255),
                Color.argb((trackA * 100f).toInt(), 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            c.drawRect(rect, p)
            p.shader = null
        } else {
            p.color = Color.argb((min(1f, trackA * 2.2f) * 255f).toInt(), 44, 44, 50)
            c.drawRect(rect, p)
        }

        // liquid fill with a wavy surface
        val fv = fill.x.coerceIn(0f, 1f)
        val fy = b - fv * ph
        val fc = Color.HSVToColor((fillA * 255f).toInt(), floatArrayOf(hue, sat, 1f))
        if (fv > 0.002f) {
            val ampPx = amp.x * 9f * d
            path.reset()
            topPath.reset()
            path.moveTo(l, b + 2f)
            for (i in 0..20) {
                val x = l + pw * i / 20f
                val y = fy + ampPx * sin(phase + i * 0.41f)
                path.lineTo(x, y)
                if (i == 0) topPath.moveTo(x, y) else topPath.lineTo(x, y)
            }
            path.lineTo(r, b + 2f)
            path.close()
            p.color = fc
            p.shader = if (glass) LinearGradient(0f, fy, 0f, b, fc, withA(fc, 0.78f), Shader.TileMode.CLAMP) else null
            c.drawPath(path, p)
            p.shader = null
            if (glass && spec > 0f) {
                c.save()
                c.clipPath(path)
                p.shader = LinearGradient(
                    l, 0f, r, 0f,
                    intArrayOf(
                        Color.argb(0, 255, 255, 255),
                        Color.argb((spec * 95f).toInt(), 255, 255, 255),
                        Color.argb(0, 255, 255, 255)
                    ),
                    floatArrayOf(0f, 0.28f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRect(rect, p)
                p.shader = null
                c.restore()
                sp.shader = null
                sp.strokeWidth = 1.6f * d
                sp.color = Color.argb((spec * 180f).toInt(), 255, 255, 255)
                c.drawPath(topPath, sp)
            }
        }

        // specular highlight near the top of the glass
        if (glass && spec > 0f) {
            val hh = min(ph * 0.3f, pw * 1.4f)
            val hw = pw * shineWidth.coerceIn(0.1f, 0.9f)
            val hy = t + (ph - hh) * shinePos
            hl.set(cx - hw / 2f, hy, cx + hw / 2f, hy + hh)
            p.shader = LinearGradient(
                0f, hl.top, 0f, hl.bottom,
                Color.argb((spec * 120f).toInt(), 255, 255, 255),
                Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            val hr = pw * 0.38f
            c.drawRoundRect(hl, hr, hr, p)
            p.shader = null
            if (refract > 0f) {
                sp.shader = null
                sp.style = Paint.Style.STROKE
                sp.strokeWidth = (1f + refract * 3.5f) * d
                sp.color = Color.argb((refract * 95f).toInt(), 255, 255, 255)
                rect2.set(l + 3f*d, t + 3f*d, r - 3f*d, b - 3f*d)
                c.drawRoundRect(rect2, max(0f, rad - 3f*d), max(0f, rad - 3f*d), sp)
                sp.strokeWidth = 1f*d
                sp.color = Color.argb((refract * 55f).toInt(), 35, 65, 115)
                rect2.set(l + 6f*d, t + 6f*d, r - 6f*d, b - 6f*d)
                c.drawRoundRect(rect2, max(0f, rad - 6f*d), max(0f, rad - 6f*d), sp)
            }
        }
        c.restore()

        // icon and percentage, flipped to a dark colour where the fill passes behind them
        val iconCy = b - pw * 0.55f
        val onFill = if (Color.luminance(fc) > 0.55f) Color.argb(235, 26, 26, 30) else Color.WHITE
        twoTone(c, fy, onFill) { col ->
            drawIcon(c, col, cx, iconCy, fv)
            if (showPct) {
                tp.color = col
                tp.textSize = pw * 0.27f
                c.drawText((fv * 100f).roundToInt().toString(), cx, t + pw * 0.62f, tp)
            }
        }

        // Dedicated One UI-style overflow affordance. Tap these three dots to expand.
        val menuY = t + 22f * d
        val menuColor = if (fv > 0.78f) Color.argb(230, 24, 29, 42) else Color.WHITE
        p.shader = null
        p.color = menuColor
        p.alpha = 235
        val dotR = 1.8f * d
        c.drawCircle(cx - 6f*d, menuY, dotR, p)
        c.drawCircle(cx, menuY, dotR, p)
        c.drawCircle(cx + 6f*d, menuY, dotR, p)
        p.alpha = 255

        // edge glow: a soft wide ring plus a thin bright rim
        if (glow > 0f) {
            sp.color = Color.WHITE
            sp.shader = LinearGradient(
                l, t, r, b,
                intArrayOf(
                    Color.argb((glow * 235f).toInt(), 255, 255, 255),
                    Color.argb((glow * 25f).toInt(), 255, 255, 255),
                    Color.argb((glow * 150f).toInt(), 255, 255, 255)
                ),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            var inset = 2.5f * d
            sp.alpha = 45
            sp.strokeWidth = 5f * d
            rect2.set(l + inset, t + inset, r - inset, b - inset)
            c.drawRoundRect(rect2, max(0f, rad - inset), max(0f, rad - inset), sp)
            inset = 0.7f * d
            sp.alpha = 255
            sp.strokeWidth = 1.4f * d
            rect2.set(l + inset, t + inset, r - inset, b - inset)
            c.drawRoundRect(rect2, max(0f, rad - inset), max(0f, rad - inset), sp)
            sp.shader = null
        }
        c.restore()
    }

    private fun twoTone(c: Canvas, fy: Float, onFill: Int, draw: (Int) -> Unit) {
        c.save()
        c.clipRect(0f, fy, width.toFloat(), height.toFloat())
        draw(onFill)
        c.restore()
        c.save()
        c.clipRect(0f, 0f, width.toFloat(), fy)
        draw(Color.WHITE)
        c.restore()
    }

    private fun drawIcon(c: Canvas, col: Int, cx: Float, cy: Float, level: Float) {
        val s = pw * 0.42f / 24f
        c.save()
        c.translate(cx - 12f * s, cy - 12f * s)
        c.scale(s, s)
        ip.style = Paint.Style.FILL
        ip.color = col
        c.drawPath(spk, ip)
        ip.style = Paint.Style.STROKE
        ip.strokeWidth = 2.1f
        ip.strokeCap = Paint.Cap.ROUND
        for (i in 0..2) {
            val al = ((level - (i * 0.3f + 0.04f)) / 0.1f).coerceIn(0f, 1f)
            if (al <= 0f) continue
            ip.color = withA(col, al)
            val rr = 4.2f + i * 3.2f
            arcRect.set(12f - rr, 12f - rr, 12f + rr, 12f + rr)
            c.drawArc(arcRect, -42f, 84f, false, ip)
        }
        val ma = (1f - level / 0.04f).coerceIn(0f, 1f)
        if (ma > 0f) {
            ip.color = withA(col, ma)
            c.drawLine(16f, 9.5f, 21.5f, 14.5f, ip)
            c.drawLine(21.5f, 9.5f, 16f, 14.5f, ip)
        }
        c.restore()
    }
}
